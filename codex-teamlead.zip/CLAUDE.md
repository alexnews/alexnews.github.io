# Project mode: Codex tandem (Claude leads, Codex codes)

This project uses the two-agent tandem. **Activate the `codex-teamlead` skill** and follow it for
all build/fix/refactor work in this repo.

Role split is strict:
- **Claude = tech lead / reviewer.** Architecture, planning, docs, GOAL specs, progress tracking,
  verification, code review, accept/reject. **Never write implementation code or tests yourself.**
- **Codex = implementer.** Writes code + tests via headless `codex exec`; fills the handoff log.

If you want to "just fix it" in a source file — stop. That is a finding to send back to Codex via
`codex-cont.sh`.

## Always
- Run `andrej-karpathy-skills:karpathy-guidelines` when designing or planning.
- EVERY Codex instance is driven by a `/goal` spec YOU write (code-verifiable acceptance criteria —
  commands that exit 0, coverage numbers, "0 high/critical" — + a mandatory handoff log). Never a
  bare one-liner, never vague adjectives. `codex-run.sh` refuses to run without `-f GOALFILE`.
- The GOAL makes Codex autonomous: it decides routine matters and logs them, and only stops for
  genuinely blocking/irreversible decisions — so it never bounces trivia back at you.
- Wait calmly for Codex; verify liveness (`tail .codex-tl/run-*.jsonl`) and watch `git diff --stat`.
- Gate every diff with `codex-verify.sh` BEFORE reviewing. Red gate → bounce back, no review.
- Review for slop / fake tests; bounce findings via `codex-cont.sh --last`, never fix them yourself.

## Project config (used in GOAL specs and the verify gate)
- Codex model:        gpt-5.5   (account default; `gpt-5-codex` is rejected on this ChatGPT account)
- Reasoning effort:   high
- Sandbox:            workspace-write has NO network — use `-s danger-full-access` when a run must
                      `npm install` new deps, or pre-install them from the host before delegating
- Stack:              Node + TypeScript (ESM), TUI via Ink, SQLite via better-sqlite3, tests via vitest
- Lint command:       npm run lint        (eslint .)
- Typecheck command:  npm run typecheck   (tsc --noEmit)
- Build command:      npm run build       (tsc -p tsconfig.json)
- Test command:       npm test            (vitest run; add `-- --coverage` for the coverage gate)
- Run command:        npm start           (node dist/index.js)
- Coverage gate:      lines >= 85%, branches >= 80% on src/ (enforced in vitest.config.ts thresholds)
- Security audit:     npm audit --audit-level=high
