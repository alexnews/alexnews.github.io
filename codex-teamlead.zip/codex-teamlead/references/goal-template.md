# GOAL spec template

Every task handed to Codex is a `/goal` spec. Codex is a strong engineer but a literal one:
vague asks produce slop. The spec is a contract. Acceptance criteria MUST be things a machine can
check (a command exits 0, a coverage number, a file exists), not adjectives.

Fill this template, save it to `.codex-tl/goal-<slug>.md`, and pass it with
`codex-run.sh -f .codex-tl/goal-<slug>.md`.

```markdown
# GOAL: <one-line outcome>

## Context
<2-5 lines: where this fits, the architecture decision already made, links to files. Keep it tight.>

## Scope
IN:  <exact files / modules / behaviours to change>
OUT: <explicitly out of bounds — do NOT touch these>

## Hard acceptance criteria (ALL must be code-verifiable and ALL green)
- [ ] `<lint cmd>` exits 0 with zero warnings
- [ ] `<typecheck cmd>` exits 0
- [ ] `<build cmd>` exits 0
- [ ] New tests cover: <behaviour A>, <behaviour B>, <edge case C>
- [ ] `<test cmd>` exits 0; coverage on <module> >= <N>% lines AND >= <M>% branches
- [ ] `<security audit cmd>` reports 0 high/critical
- [ ] No new TODO/FIXME, no commented-out code, no `any`/`@ts-ignore` (unless justified inline)
- [ ] Public API unchanged UNLESS listed here: <...>

## Constraints (karpathy-guidelines)
- Smallest diff that satisfies the criteria. No drive-by refactors outside Scope IN.
- No new dependencies without listing them + one-line justification in the handoff.
- Match surrounding code style; no reformatting unrelated lines.

## Autonomy (the OPERATING CONTRACT is auto-prepended to every run — restated here)
- Work to completion without bouncing trivia back. For routine choices (naming, layout, test
  structure, obvious edge cases) pick the best convention and KEEP GOING; record non-obvious ones in
  Decisions/Deviations.
- STOP (end with a `BLOCKED:` line) ONLY for a genuinely load-bearing, ambiguous, hard-to-reverse
  decision — unauthorized API/contract change, destructive migration, missing credential, or two
  spec readings that yield materially different systems. Never stop for trivia.

## Mandatory handoff (write to .codex-tl/handoff-<slug>.md before finishing)
The final turn MUST create/overwrite this file with these sections:
1. **Actions log** — ordered list of what was changed and why (file:line granularity).
2. **Decisions** — non-obvious choices made and the reasoning.
3. **Deviations** — anything done differently from this spec, with the reason. "none" if none.
4. **Verification** — the exact commands run and their pasted results (lint/build/test/coverage/audit).
5. **Handoff** — what the reviewer should look at first; known risks; follow-ups out of scope.

Do NOT claim a criterion is met without the command output in section 4.
```

## Why hard criteria

A criterion like "good test coverage" is unreviewable — Codex will declare victory. `coverage >=
85% branches on src/auth, command pasted` is checkable: `codex-verify.sh` (or the reviewer) re-runs
it. If the gate is red, the work bounces back via `codex-cont.sh` with the failing output quoted —
no debate.
