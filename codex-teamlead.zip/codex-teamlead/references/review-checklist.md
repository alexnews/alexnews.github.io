# Review checklist (the human-judgement half)

Run AFTER `codex-verify.sh` is GREEN. A green gate proves it compiles and tests pass — it does NOT
prove the tests are honest or the design is sound. That is this pass. Default to skepticism: assume
the agent optimised to make the gate pass, and look for where it cut the corner.

## 1. Test honesty (anti-slop — the #1 thing Codex fakes)
- Do tests assert real behaviour, or just that code ran without throwing? Hunt for:
  - `expect(true).toBe(true)`, snapshot-only tests, tests with no assertions.
  - Assertions on mocks instead of real output (mock returns X, test asserts X — tautology).
  - Tests that would still pass if the implementation were deleted/stubbed. Mentally delete a
    branch — does a test go red? If not, coverage is theatre.
  - Coverage hit by calling code but asserting nothing.
  - Edge cases from the GOAL spec actually exercised (empty, null, boundary, error paths)?
- Spot-check: pick one new test, break the implementation it covers, confirm it fails.

## 2. Correctness
- Off-by-one, null/undefined, async race, unhandled rejection, error swallowed with empty catch.
- Does the change actually satisfy the GOAL outcome, not just the literal criteria?
- Concurrency / ordering assumptions valid?

## 3. Diff discipline (karpathy-guidelines)
- Diff is the SMALLEST that solves it? Flag drive-by refactors, reformatting, scope creep.
- Any new dependency justified? Any `any` / `@ts-ignore` / `eslint-disable` / `unwrap()` slipped in?
- Dead code, commented-out blocks, leftover debug logs, TODO/FIXME?
- Naming/style matches the surrounding file?

## 4. Security & robustness
- Input validation on boundaries; no injection (SQL/shell/path); secrets not logged/committed.
- `codex-verify.sh` audit gate green (no high/critical).
- Resource cleanup (handles, listeners, transactions) on all paths.

## 5. The handoff itself
- `.codex-tl/handoff-<slug>.md` exists and is REAL (not generic filler).
- Section 4 has actual pasted command output, not "tests pass".
- Deviations honestly disclosed and acceptable.

## Tooling for this pass
- Prefer the `/code-review` skill or the `feature-dev:code-reviewer` / `superpowers:code-reviewer`
  agent on the diff for a second set of eyes — then apply your own judgement on top.
- For a deeper independent look, dispatch a review subagent (see SKILL.md).

## Verdict
- **GREEN** (gate green + review clean): accept, update progress, move on.
- **RED** (any finding): bounce back with `codex-cont.sh`. Quote each finding as a numbered,
  checkable item. Do NOT fix it yourself — that is Codex's job. Re-run the full loop on return.
