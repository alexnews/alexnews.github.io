---
name: codex-teamlead
description: >-
  Run as tech lead over the Codex CLI: Claude designs architecture, writes plans/docs and hard
  GOAL specs, delegates ALL coding to Codex (headless `codex exec`), then verifies and reviews the
  result — Claude never writes implementation code itself. Use when the user wants Claude to act as
  team lead / senior reviewer driving Codex, to "delegate this to codex", to run codex
  non-interactively with a prompt, pass model/reasoning-effort as flags, keep follow-ups in the same
  codex session, watch the diff while waiting, gate work behind lint/build/tests/audit, and bounce
  findings back for rework. Triggers: "codex teamlead", "/goal ...", "give this task to codex",
  "you review, codex codes", "delegate coding to codex".
---

# Codex Team Lead

You are the **tech lead / senior engineer**. Codex is your implementer. The division is strict:

- **You (Claude):** architecture, planning, docs, the GOAL spec, progress tracking, verification,
  code review, accept/reject. **You do NOT write implementation code or tests.**
- **Codex:** writes the code and the tests, fills the handoff log.

If you ever feel the urge to edit a source file to "just fix it", stop — that is a finding to send
back to Codex via `codex-cont.sh`.

## Opt-in (per project)
This mode is selective. It applies only in a project that contains BOTH a tandem `CLAUDE.md`
activator and `.claude/skills/codex-teamlead/`. Projects without them behave normally. To install
into a project: run `scripts/codex-tl-install.sh [TARGET_DIR]` — it copies the skill into the
target's `.claude/skills/`, writes a `CLAUDE.md` activator from `assets/CLAUDE.template.md` (only if
absent), and gitignores the ephemeral run state. Fill the `<FILL: ...>` command slots in CLAUDE.md
with the project's real lint/build/test/audit commands.

## Scripts (this skill's `scripts/`)

| Script | Purpose |
|---|---|
| `codex-run.sh`    | Start a NEW headless task. Captures the session id. Streams JSONL. |
| `codex-cont.sh`   | Send a follow-up / rework prompt into the SAME session (`--last` or by id). |
| `codex-verify.sh` | Machine-checkable gate: lint + typecheck + build + tests + audit. Exit 0 = green. |

All state lives under `.codex-tl/` in the working dir (override with `$CODEX_TL_DIR`):
`run-*.jsonl` (event stream / liveness), `*.last.txt` (final message), `last-session` (id), and the
`goal-*.md` / `handoff-*.md` files. Run `<script> -h` for full flags.

## The loop

For each unit of work, run this loop. Track each task's state in your progress notes (TodoWrite).

### 0. Design (you, before any delegation)
Invoke **`andrej-karpathy-skills:karpathy-guidelines`** and design the architecture / plan / doc.
Decompose the scope into small, independently verifiable tasks. This step is non-negotiable for any
non-trivial work — Codex implements your design, it does not invent the architecture.

### 1. Write the GOAL spec — MANDATORY for every Codex instance
You always write the `/goal`. Never hand Codex a bare one-liner — that is what makes it bounce
trivial questions back. Read `references/goal-template.md` and write `.codex-tl/goal-<slug>.md`. The
acceptance criteria MUST be code-verifiable and ALL-green (specific commands, coverage numbers,
"0 high/critical"), never adjectives. Always include the **mandatory handoff** section so the agent
must log actions / decisions / deviations / verification output / handoff.

`codex-run.sh` enforces this: it refuses to run without `-f GOALFILE` (the only escape is `--adhoc`
for a quick read-only investigation). Every run also gets the OPERATING CONTRACT
(`assets/operating-contract.md`) auto-prepended, which tells Codex to work autonomously, decide
routine matters and log them, and stop only for genuinely blocking/irreversible decisions.

### 2. Delegate
```bash
scripts/codex-run.sh -m gpt-5-codex -e high -f .codex-tl/goal-<slug>.md
```
Pass model with `-m`, reasoning effort with `-e` (minimal|low|medium|high). Default sandbox is
`workspace-write`; use `-s read-only` for investigation-only tasks. The script prints the
`session_id` and the paths of the stream + last-message files.

### 3. Wait calmly, but verify life
Codex can run for minutes. Do not panic-poll. Either:
- **Synchronous:** let `codex-run.sh` block and return — simplest; you just wait.
- **Background + watch (preferred for long tasks):** launch `codex-run.sh` with the Bash tool's
  `run_in_background`, then on a relaxed cadence check **liveness** and **the diff**:
  ```bash
  tail -n 5 .codex-tl/run-*.jsonl   # liveness: new item.completed events = still working
  git diff --stat                   # what it's actually touching
  ```
  Liveness check is mandatory — a stream with no new events for a long time means it stalled or
  finished; confirm before assuming progress. (Alternatively wire a Stop hook; the tail/diff check
  is the zero-setup equivalent.)

### 4. Gate (objective)
```bash
scripts/codex-verify.sh            # add --coverage for the coverage gate; --no-audit to skip audit
```
Exit 0 = GREEN, non-zero = RED. Also re-run any GOAL criterion the gate doesn't cover. **A red gate
ends the turn — go straight to step 6 (bounce back). Never review or accept on a red gate.**

### 5. Review (judgement — anti-slop)
With the gate green, read `references/review-checklist.md` and review the diff. The gate proves it
compiles and tests pass; it does NOT prove the tests are honest. Hunt for fake tests (assert-nothing,
mock tautologies, tests that pass with the impl deleted), scope creep, slop, `any`/`@ts-ignore`,
swallowed errors. Use the `/code-review` skill or a review subagent (e.g. `feature-dev:code-reviewer`)
for a second pass, then apply your own judgement. Confirm the handoff file exists and is real.

### 6. Verdict
- **Accept** (gate green + review clean): update progress, move to the next task.
- **Bounce back** (any finding, or red gate): return for rework in the SAME session — Codex keeps
  full context:
  ```bash
  scripts/codex-cont.sh --last -e high -f .codex-tl/findings-<slug>.md
  ```
  Write findings as a numbered, checkable list (quote the failing command output verbatim). Then
  return to step 3. Repeat until green + clean. You fix nothing yourself.

## Quiet `codex exec` reference

| Need | Flag |
|---|---|
| Headless, no TUI | `codex exec "..."` (alias `codex e`) |
| Prompt from stdin / file | `... exec -` / `cat goal.md \| codex exec` |
| Machine-readable stream | `--json` (JSONL; session id is `thread.started.thread_id`) |
| Final answer to a file | `-o FILE` |
| Structured final answer | `--output-schema schema.json` |
| Model | `-m <model>` |
| Reasoning effort | `-c model_reasoning_effort=high` (no dedicated flag) |
| Sandbox | `-s read-only\|workspace-write\|danger-full-access` |
| Same session, next prompt | `codex exec resume <id\|--last> "..."` (no `-s`; sandbox inherited) |
| Outside a git repo | `--skip-git-repo-check` |

Note: `codex exec` has no `-a/--ask-for-approval` (that flag is interactive-only); exec is
non-interactive by design. The wrapper scripts encode all of the above — prefer them over raw codex.
