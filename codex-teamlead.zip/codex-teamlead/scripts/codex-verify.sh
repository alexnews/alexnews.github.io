#!/usr/bin/env bash
# codex-verify.sh — machine-checkable quality gate for the diff Codex produced.
#
# This is the OBJECTIVE half of review: lint + typecheck + build + tests + security audit.
# Exit code is the verdict — 0 = all gates green, non-zero = at least one gate failed.
# Run this BEFORE the human-judgement code review. Never trust "it's done" without a green gate.
#
# Auto-detects the stack (Node/TS by lockfile, Rust by Cargo.toml). Each gate runs only if it
# applies. Missing-but-expected gates are reported as SKIP, not silently dropped.
#
# Usage:
#   codex-verify.sh [--coverage] [--no-audit] [--cd DIR]
#
# Options:
#   --coverage     run tests with coverage (npm: `test -- --coverage`; cargo: llvm-cov if present)
#   --no-audit     skip the security audit gate
#   --cd DIR       run in DIR
#   -h, --help
set -uo pipefail

COVERAGE=false DO_AUDIT=true WORKDIR="."
while [[ $# -gt 0 ]]; do
  case "$1" in
    --coverage) COVERAGE=true; shift;;
    --no-audit) DO_AUDIT=false; shift;;
    --cd)       WORKDIR="$2"; shift 2;;
    -h|--help)  sed -n '2,22p' "$0" | sed 's/^# \{0,1\}//'; exit 0;;
    *)          echo "codex-verify: unknown option $1" >&2; exit 2;;
  esac
done
cd "$WORKDIR" || { echo "codex-verify: cannot cd $WORKDIR" >&2; exit 2; }

FAILED=() PASSED=() SKIPPED=()
run_gate() { # name, cmd...
  local name="$1"; shift
  echo "----- [$name] $* -----"
  if "$@"; then PASSED+=("$name"); echo "[$name] PASS"
  else local rc=$?; FAILED+=("$name"); echo "[$name] FAIL (exit $rc)"; fi
}
skip_gate() { SKIPPED+=("$1"); echo "----- [$1] SKIP: $2 -----"; }

has_script() { node -e "process.exit(require('./package.json').scripts?.['$1']?0:1)" 2>/dev/null; }
script_has() { node -e "process.exit((require('./package.json').scripts?.['$1']||'').includes('$2')?0:1)" 2>/dev/null; }

# ---------- Node / TypeScript ----------
if [[ -f package.json ]]; then
  if   [[ -f pnpm-lock.yaml ]]; then PM=pnpm; X="pnpm";        RUN="pnpm run"
  elif [[ -f yarn.lock ]];      then PM=yarn; X="yarn";        RUN="yarn"
  elif [[ -f bun.lockb ]];      then PM=bun;  X="bunx";        RUN="bun run"
  else                               PM=npm;  X="npx";         RUN="npm run"; fi
  echo "### Node project (package manager: $PM)"

  if has_script lint; then run_gate lint $RUN lint; else skip_gate lint "no \"lint\" script"; fi

  if has_script typecheck; then run_gate typecheck $RUN typecheck
  elif [[ -f tsconfig.json ]]; then run_gate typecheck $X tsc --noEmit
  else skip_gate typecheck "no typecheck script / tsconfig"; fi

  if has_script build; then run_gate build $RUN build; else skip_gate build "no \"build\" script"; fi

  if has_script test; then
    # Only inject --coverage when the test script doesn't already enable it (avoids a duplicate flag).
    if $COVERAGE && ! script_has test coverage; then run_gate test $RUN test -- --coverage
    else run_gate test $RUN test; fi
  else skip_gate test "no \"test\" script"; fi

  if $DO_AUDIT; then
    case "$PM" in
      npm)  run_gate audit npm  audit --audit-level=high;;
      pnpm) run_gate audit pnpm audit --audit-level high;;
      yarn) run_gate audit yarn npm audit --severity high 2>/dev/null || run_gate audit yarn audit --level high;;
      bun)  skip_gate audit "bun has no audit; run npm audit manually";;
    esac
  else skip_gate audit "--no-audit"; fi
fi

# ---------- Rust ----------
if [[ -f Cargo.toml ]]; then
  echo "### Rust project"
  command -v cargo >/dev/null && {
    run_gate clippy cargo clippy --all-targets --all-features -- -D warnings
    run_gate build  cargo build --all-targets
    if $COVERAGE && cargo llvm-cov --version >/dev/null 2>&1; then run_gate test cargo llvm-cov
    else run_gate test cargo test --all-features; fi
    $DO_AUDIT && { command -v cargo-audit >/dev/null && run_gate audit cargo audit || skip_gate audit "cargo-audit not installed"; }
  } || skip_gate rust "cargo not on PATH"
fi

if [[ ! -f package.json && ! -f Cargo.toml ]]; then
  echo "codex-verify: no package.json or Cargo.toml detected — add gates for this stack manually" >&2
fi

echo
echo "================ verify gate ================"
echo "PASS : ${PASSED[*]:-none}"
echo "SKIP : ${SKIPPED[*]:-none}"
echo "FAIL : ${FAILED[*]:-none}"
echo "============================================"
[[ ${#FAILED[@]} -eq 0 ]] || { echo "GATE: RED"; exit 1; }
echo "GATE: GREEN"
