#!/usr/bin/env bash
# codex-cont.sh — send a follow-up / rework prompt into an EXISTING Codex session.
#
# Use after review findings: return the work for rework in the same conversation so Codex keeps
# full context. Same JSONL/headless contract as codex-run.sh.
#
# Usage:
#   codex-cont.sh --last "rework prompt..."
#   codex-cont.sh <SESSION_ID> "rework prompt..."
#   codex-cont.sh --last -f findings.md
#   echo "..." | codex-cont.sh --last
#
# Options:
#   --last                 resume the most recent session recorded by codex-run.sh / codex
#   -m, --model   <name>   model override
#   -e, --effort  <level>  reasoning effort: minimal|low|medium|high
#   -s, --sandbox <mode>   read-only|workspace-write|danger-full-access (default: workspace-write)
#   -f, --file    <path>   read the prompt from a file
#   -h, --help
set -uo pipefail

SID="" USE_LAST=false MODEL="" EFFORT="" SANDBOX="" PROMPT_FILE=""
RUN_DIR="${CODEX_TL_DIR:-.codex-tl}"
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
POS=()
UUID_RE='^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'

usage() { sed -n '2,25p' "$0" | sed 's/^# \{0,1\}//'; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --last)       USE_LAST=true; shift;;
    -m|--model)   MODEL="$2"; shift 2;;
    -e|--effort)  EFFORT="$2"; shift 2;;
    -s|--sandbox) SANDBOX="$2"; shift 2;;
    -f|--file)    PROMPT_FILE="$2"; shift 2;;
    -h|--help)    usage; exit 0;;
    --)           shift; POS+=("$@"); break;;
    -*)           echo "codex-cont: unknown option $1" >&2; exit 2;;
    *)            POS+=("$1"); shift;;
  esac
done

# A leading positional is the SESSION_ID only when it is a real UUID and --last was not given.
if [[ "$USE_LAST" == false && ${#POS[@]} -gt 0 && "${POS[0]}" =~ $UUID_RE ]]; then
  SID="${POS[0]}"; POS=("${POS[@]:1}")
fi

# resolve session: explicit id wins; else --last flag; else fall back to recorded last-session id.
RESUME_ARGS=()
if [[ -n "$SID" ]]; then RESUME_ARGS=("$SID")
elif [[ "$USE_LAST" == true ]]; then RESUME_ARGS=(--last)
elif [[ -f "$RUN_DIR/last-session" ]]; then SID="$(cat "$RUN_DIR/last-session")"; RESUME_ARGS=("$SID")
else echo "codex-cont: no session (pass <SESSION_ID>, --last, or run codex-run first)" >&2; exit 2; fi

if [[ -n "$PROMPT_FILE" ]]; then BODY="$(cat "$PROMPT_FILE")"
elif [[ ${#POS[@]} -gt 0 ]]; then BODY="${POS[*]}"
elif [[ ! -t 0 ]]; then BODY="$(cat)"
else echo "codex-cont: no prompt (arg, -f, or stdin)" >&2; exit 2; fi
[[ -z "${BODY// /}" ]] && { echo "codex-cont: empty prompt" >&2; exit 2; }

# Re-assert the OPERATING CONTRACT on rework so Codex stays autonomous and updates the handoff.
CONTRACT="$SKILL_DIR/assets/operating-contract.md"
if [[ -f "$CONTRACT" ]]; then
  PROMPT="$(cat "$CONTRACT")"$'\n\n---\n# REWORK — address every finding below, then update the handoff\n\n'"$BODY"
else PROMPT="$BODY"; fi

command -v codex >/dev/null || { echo "codex-cont: codex not on PATH" >&2; exit 127; }

mkdir -p "$RUN_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
LOG="$RUN_DIR/cont-$TS.jsonl"
LAST="$RUN_DIR/cont-$TS.last.txt"

# NOTE: `codex exec resume` has no -s/--sandbox; the sandbox is inherited from the original
# session. Override it (rarely needed) via config key sandbox_mode.
ARGS=(exec resume "${RESUME_ARGS[@]}" --json --skip-git-repo-check -o "$LAST")
[[ -n "$MODEL" ]]   && ARGS+=(-m "$MODEL")
[[ -n "$EFFORT" ]]  && ARGS+=(-c "model_reasoning_effort=$EFFORT")
[[ -n "$SANDBOX" ]] && ARGS+=(-c "sandbox_mode=$SANDBOX")

echo ">> codex ${ARGS[*]} <prompt>" >&2
codex "${ARGS[@]}" "$PROMPT" < /dev/null | tee "$LOG"
RC=${PIPESTATUS[0]}

NEWSID="$(grep -m1 '"thread.started"' "$LOG" | jq -r '.thread_id // empty' 2>/dev/null)"
[[ -n "$NEWSID" ]] && printf '%s\n' "$NEWSID" > "$RUN_DIR/last-session"

{
  echo
  echo "================ codex-cont summary ================"
  echo "session_id : ${NEWSID:-${SID:-<last>}}"
  echo "exit_code  : $RC"
  echo "stream     : $LOG"
  echo "last_msg   : $LAST"
  echo "==================================================="
} >&2

exit "$RC"
