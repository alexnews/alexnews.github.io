#!/usr/bin/env bash
# codex-tl-install.sh — install the codex-teamlead skill into a project (per-project, opt-in).
#
# Copies this skill into <target>/.claude/skills/codex-teamlead/ and drops a CLAUDE.md activator
# into the project root (from the template, only if absent). Projects without these stay normal.
#
# Usage:
#   codex-tl-install.sh [TARGET_DIR]      # default: current directory
#   codex-tl-install.sh --force [TARGET]  # overwrite an existing project skill copy
#
# Source of truth is the skill dir this script lives in, so it works whether run from the global
# copy (~/.claude/skills/codex-teamlead) or from a project copy.
set -euo pipefail

FORCE=false
TARGET="."
for a in "$@"; do
  case "$a" in
    --force) FORCE=true;;
    -h|--help) sed -n '2,16p' "$0" | sed 's/^# \{0,1\}//'; exit 0;;
    -*) echo "codex-tl-install: unknown option $a" >&2; exit 2;;
    *) TARGET="$a";;
  esac
done

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="$(cd "$TARGET" && pwd)"
DEST="$TARGET/.claude/skills/codex-teamlead"

[[ "$SRC" == "$DEST" ]] && { echo "codex-tl-install: source == target, nothing to do" >&2; exit 0; }

if [[ -d "$DEST" && "$FORCE" == false ]]; then
  echo "codex-tl-install: $DEST already exists (use --force to overwrite)" >&2; exit 1
fi

mkdir -p "$DEST"
# copy skill payload (not the project's own .codex-tl state if SRC happens to be a project)
for item in SKILL.md scripts references assets; do
  [[ -e "$SRC/$item" ]] && cp -R "$SRC/$item" "$DEST/"
done
chmod +x "$DEST"/scripts/*.sh 2>/dev/null || true
echo "installed skill -> $DEST"

# CLAUDE.md activator (do not clobber an existing one)
if [[ -f "$TARGET/CLAUDE.md" ]]; then
  echo "kept existing $TARGET/CLAUDE.md — merge the tandem block from assets/CLAUDE.template.md manually"
elif [[ -f "$SRC/assets/CLAUDE.template.md" ]]; then
  # strip the leading HTML instruction comment, keep the activator body
  awk 'f{print} /-->/{f=1}' "$SRC/assets/CLAUDE.template.md" | sed '/./,$!d' > "$TARGET/CLAUDE.md"
  echo "wrote activator -> $TARGET/CLAUDE.md (fill the <FILL: ...> command slots)"
fi

# keep ephemeral run state out of git, keep goal/handoff artifacts tracked
GI="$TARGET/.gitignore"
if ! grep -qs '\.codex-tl/' "$GI" 2>/dev/null; then
  {
    echo ""
    echo "# codex-teamlead: ephemeral run state (keep goal-*.md / handoff-*.md tracked)"
    echo ".codex-tl/*.jsonl"
    echo ".codex-tl/*.last.txt"
    echo ".codex-tl/last-session"
  } >> "$GI"
  echo "updated $GI"
fi

echo "done. open the project and the codex-teamlead skill will activate via CLAUDE.md."
