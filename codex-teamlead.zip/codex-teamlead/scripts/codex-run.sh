#!/usr/bin/env bash
# codex-run.sh — delegate a NEW task to Codex (headless), capture session id, stream + persist.
#
# Claude is the tech lead: it writes the GOAL spec and runs this. Codex writes the code.
# Output is JSONL (no TUI). The session id (thread_id) is captured so follow-ups land in the
# same conversation via codex-cont.sh.
#
# Every Codex instance MUST be driven by a written /goal spec (pass -f). This is mandatory so Codex
# works autonomously and does not bounce trivial questions back. An OPERATING CONTRACT (autonomy
# rules) is auto-prepended to the prompt. Use --adhoc only for a quick read-only investigation.
#
# Usage:
#   codex-run.sh [opts] -f goal.md
#   codex-run.sh --adhoc [opts] "quick read-only question..."
#
# Options:
#   -f, --file    <path>     GOAL spec file (REQUIRED unless --adhoc). See references/goal-template.md
#   --adhoc                  allow a bare inline/stdin prompt (quick read-only task; no goal file)
#   -m, --model   <name>     model (default: codex config default, e.g. gpt-5-codex)
#   -e, --effort  <level>    reasoning effort: minimal|low|medium|high (|xhigh on some models)
#   -s, --sandbox <mode>     read-only|workspace-write|danger-full-access (default: workspace-write)
#   -C, --cd      <dir>      working root for the agent
#   -h, --help
#
# State (under $CODEX_TL_DIR, default .codex-tl/):
#   run-<ts>.jsonl       full event stream (liveness: tail this)
#   run-<ts>.last.txt    final agent message
#   last-session         session id for codex-cont.sh --last
set -uo pipefail

MODEL="" EFFORT="" SANDBOX="workspace-write" CD_DIR="" PROMPT_FILE="" ADHOC=false
RUN_DIR="${CODEX_TL_DIR:-.codex-tl}"
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

usage() { sed -n '2,32p' "$0" | sed 's/^# \{0,1\}//'; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    -m|--model)   MODEL="$2"; shift 2;;
    -e|--effort)  EFFORT="$2"; shift 2;;
    -s|--sandbox) SANDBOX="$2"; shift 2;;
    -C|--cd)      CD_DIR="$2"; shift 2;;
    -f|--file)    PROMPT_FILE="$2"; shift 2;;
    --adhoc)      ADHOC=true; shift;;
    -h|--help)    usage; exit 0;;
    --)           shift; break;;
    -*)           echo "codex-run: unknown option $1" >&2; exit 2;;
    *)            break;;
  esac
done

# Enforce: a /goal spec file is mandatory unless this is an explicit --adhoc quick task.
if [[ -z "$PROMPT_FILE" && "$ADHOC" == false ]]; then
  echo "codex-run: every Codex instance needs a /goal spec. Pass -f GOALFILE (see" >&2
  echo "           references/goal-template.md), or --adhoc for a quick read-only task." >&2
  exit 2
fi

if [[ -n "$PROMPT_FILE" ]]; then GOAL="$(cat "$PROMPT_FILE")"
elif [[ $# -gt 0 ]]; then GOAL="$*"
elif [[ ! -t 0 ]]; then GOAL="$(cat)"
else echo "codex-run: no prompt (-f, arg, or stdin)" >&2; exit 2; fi
[[ -z "${GOAL// /}" ]] && { echo "codex-run: empty prompt" >&2; exit 2; }

# Auto-prepend the OPERATING CONTRACT (autonomy rules) so Codex does not stall on trivia.
CONTRACT="$SKILL_DIR/assets/operating-contract.md"
if [[ -f "$CONTRACT" ]]; then
  PROMPT="$(cat "$CONTRACT")"$'\n\n---\n# GOAL\n\n'"$GOAL"
else PROMPT="$GOAL"; fi

command -v codex >/dev/null || { echo "codex-run: codex not on PATH" >&2; exit 127; }

mkdir -p "$RUN_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
LOG="$RUN_DIR/run-$TS.jsonl"
LAST="$RUN_DIR/run-$TS.last.txt"

ARGS=(exec --json --skip-git-repo-check -s "$SANDBOX" -o "$LAST")
[[ -n "$MODEL" ]]  && ARGS+=(-m "$MODEL")
[[ -n "$EFFORT" ]] && ARGS+=(-c "model_reasoning_effort=$EFFORT")
[[ -n "$CD_DIR" ]] && ARGS+=(-C "$CD_DIR")

echo ">> codex ${ARGS[*]} <prompt>" >&2
codex "${ARGS[@]}" "$PROMPT" < /dev/null | tee "$LOG"
RC=${PIPESTATUS[0]}

SID="$(grep -m1 '"thread.started"' "$LOG" | jq -r '.thread_id // empty' 2>/dev/null)"
[[ -n "$SID" ]] && printf '%s\n' "$SID" > "$RUN_DIR/last-session"

{
  echo
  echo "================ codex-run summary ================"
  echo "session_id : ${SID:-<not captured>}"
  echo "exit_code  : $RC"
  echo "stream     : $LOG"
  echo "last_msg   : $LAST"
  echo "resume     : codex-cont.sh --last \"...\"   (or: codex-cont.sh $SID \"...\")"
  echo "=================================================="
} >&2

exit "$RC"
