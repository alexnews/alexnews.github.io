<!--
  Codex tandem mode — OPT-IN.
  Copy this file to a project's root as CLAUDE.md to make Claude operate as tech lead over Codex
  in THAT project only. Projects without this file behave normally. Fill the <FILL: ...> slots
  with this project's real commands, then delete this comment block.
-->

# Project mode: Codex tandem (Claude leads, Codex codes)

This project uses the two-agent tandem. **Activate the `codex-teamlead` skill** and follow it for
all build/fix/refactor work in this repo.

Role split is strict:
- **Claude = tech lead / reviewer.** Architecture, planning, docs, GOAL specs, progress tracking,
  verification, code review, accept/reject. **Never write implementation code or tests yourself.**
- **Codex = implementer.** Writes code + tests via headless `codex exec`; fills the handoff log.

If you want to "just fix it" in a source file — stop. That is a finding to send back to Codex via
`codex-cont.sh`.

## Always
- Run `andrej-karpathy-skills:karpathy-guidelines` when designing or planning.
- EVERY Codex instance is driven by a `/goal` spec YOU write (code-verifiable acceptance criteria —
  commands that exit 0, coverage numbers, "0 high/critical" — + a mandatory handoff log). Never a
  bare one-liner, never vague adjectives. `codex-run.sh` refuses to run without `-f GOALFILE`.
- The GOAL makes Codex autonomous: it decides routine matters and logs them, and only stops for
  genuinely blocking/irreversible decisions — so it never bounces trivia back at you.
- Wait calmly for Codex; verify liveness (`tail .codex-tl/run-*.jsonl`) and watch `git diff --stat`.
- Gate every diff with `codex-verify.sh` BEFORE reviewing. Red gate → bounce back, no review.
- Review for slop / fake tests; bounce findings via `codex-cont.sh --last`, never fix them yourself.

## Project config (used in GOAL specs and the verify gate)
- Codex model:        <FILL: e.g. gpt-5-codex>
- Reasoning effort:   <FILL: minimal|low|medium|high>
- Sandbox:            <FILL: read-only | workspace-write | danger-full-access>
- Lint command:       <FILL: e.g. npm run lint>
- Typecheck command:  <FILL: e.g. npx tsc --noEmit  |  n/a>
- Build command:      <FILL: e.g. npm run build  |  n/a>
- Test command:       <FILL: e.g. npm test>
- Coverage gate:      <FILL: e.g. lines >= 85%, branches >= 80% on src/>
- Security audit:     <FILL: e.g. npm audit --audit-level=high>

If a command above differs from what `codex-verify.sh` auto-detects, state it explicitly in each
GOAL spec so Codex and the gate use the project's real commands.
